import azure.functions as func
import logging
from PIL import Image
import io

app = func.FunctionApp()

@app.function_name("process_image")
@app.blob_trigger(arg_name="myblob", 
                 path="samples-workitems/{name}",
                 source="EventGrid",
                 connection="fbd114_STORAGE")
@app.blob_output(arg_name="outputblob",
                path="processed-images/{name}",
                connection="fbd114_STORAGE")
def process_image(myblob: func.InputStream, outputblob: func.Out[bytes]):
    logging.info("Processing blob")
    
    try:
        # Deliberately throw an exception for testing
        #raise Exception(" exception: error in a processing image!")
        
        # This code won't be reached due to the exception above
        image_data = myblob.read()
        img = Image.open(io.BytesIO(image_data))
        
        # Calculate new dimensions (800px width)
        base_width = 800
        w_percent = (base_width / float(img.size[0]))
        h_size = int((float(img.size[1]) * float(w_percent)))
        
        # Resize image
        img = img.resize((base_width, h_size), Image.Resampling.LANCZOS)
        
        # Convert to bytes for output binding
        output = io.BytesIO()
        img.save(output, format='JPEG', quality=85)
        output.seek(0)
        
        # Write to output binding
        outputblob.set(output.getvalue())
        
        logging.info("Successfully processed image")
        
    except Exception as e:
        logging.error(f"Error processing image: {str(e)}")
        raise  # Re-raise the exception after logging it
